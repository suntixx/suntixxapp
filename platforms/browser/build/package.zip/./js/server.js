var Server = {

  eventImageUpload: config.server + "/api/uploadify/1",
  userImageUpload: config.server + "/api/useruploadify",
  ticketImageUpload: config.server + "/api/ticketuploadify",


};
